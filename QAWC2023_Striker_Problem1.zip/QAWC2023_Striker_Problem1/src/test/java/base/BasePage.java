package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import utils.ExtentManager;

public class BasePage {

	public ExtentReports extent = ExtentManager.getInstance();
	public ExtentTest test;
	public static WebDriver driver;

	public static void initializeBrowser(String browser) {
		// Open browser instance
		switch (browser) {
		case "chrome":
			ChromeOptions options = new ChromeOptions();
			options.addArguments("start-maximized");
			options.addArguments("test-type");
			options.addArguments("enable-strict-powerful-feature-restrictions");
			options.addArguments("disable-geolocation");
			options.addArguments("--disable-notifications");
			driver = new ChromeDriver(options);
			break;
		case "firefox":
			driver = new FirefoxDriver();
			break;
		}
	}

	public static void navigatToUrl(String url) {
		// Open the URL
		driver.get(url);
	}

	public static void tearDown() {
		// driver.close(); // Close current instance of browser
		driver.quit(); // Close all the browser instances
	}
}