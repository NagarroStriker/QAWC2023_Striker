package base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Data {

	public static void main(String[] args) {
		String excelFilePath = System.getProperty("user.dir") + "//ProjectData.xlsx";

		Xls_Reader excelFile = new Xls_Reader(excelFilePath);

		HashMap<String, String> projectsData = new HashMap<String, String>();

		List<String> projectValues = new ArrayList<String>();

		String[] projects = new String[] {"Project1", "Project2", "Project3"};

		System.out.println(projects[0]);

		for(int i=2; i<5;i++) {

		String project = projects[i-2];

		String totalNumOfTestCases1 = excelFile.getCellData("projects", "No of test cases to be Automated", 2);

		// excelFile.getCellData("projects", "", i);

		String duration1 = excelFile.getCellData("projects", "Project Duration(years)", 2);

		String platforms1 = excelFile.getCellData("projects", "Platforms Supported", 2);

		String executionPerweek1 = excelFile.getCellData("projects", "No of Execution Cyles per week", 2);

		String PDToolsSetUp1 = excelFile.getCellData("projects", "PDs requried for Framework/Tool Setup", 2);

		String trainingTime1 = excelFile.getCellData("projects", "PDs for Framework/Tool Training Time", 2);

		String custTime1 = excelFile.getCellData("projects", "PDs Framework Customization time", 2);

		String highComplexity1 = excelFile.getCellData("projects", "Percentage of test cases with High complexity", 2);

		String mediumComplex1 = excelFile.getCellData("projects", "Percentage of test cases with Medium Complexity.", 2);

		String coveragePercent1 = excelFile.getCellData("projects", "Desired Test Automation coverage percentage", 2);

		String costHourly1 = excelFile.getCellData("projects", "Hourly cost of automation engineer", 2);

		System.out.println(projectValues);

		}
	}
}
