package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import base.BasePage;
import pages.BeforeSliding;
import utils.PropertyFileReader;

public class FirstTest extends BasePage{
	
	@BeforeMethod
	public void setup() {
		test = extent.startTest(this.getClass().getName());
		BasePage.initializeBrowser(PropertyFileReader.getData("browser"));
		test.log(LogStatus.INFO, "Starting nagarro website test.");
		test.log(LogStatus.INFO, "Opening browser.");
	}
	
	@Test
	public void LetsFindOut() throws InterruptedException {
		test.log(LogStatus.INFO, "Opening application URL.");
		BasePage.navigatToUrl(PropertyFileReader.getData("url"));
		test.log(LogStatus.INFO, "Doing mouse hover and then click on submenu item.");
		BeforeSliding.TillSlidingAndClicking();
		test.log(LogStatus.INFO, "Scrolling down the page and clicking on lets find out button..");
		BeforeSliding.TillScrollingAndClicking();
	}
	
	@AfterMethod
	public void teardown() {
		if(extent!=null) {
			extent .endTest(test);
			extent.flush();
			}
		BasePage.tearDown();
	}	
}
