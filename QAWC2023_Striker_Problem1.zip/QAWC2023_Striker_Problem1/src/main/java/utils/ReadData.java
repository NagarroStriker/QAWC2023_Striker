package utils;

public class ReadData {

}
